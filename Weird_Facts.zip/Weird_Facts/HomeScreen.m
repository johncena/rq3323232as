//
//  HomeScreen.m
//  MJSAppTemplate
//
//  Created by Pairroxz on 15/01/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "HomeScreen.h"
#import "MoreFreeAppScreen.h"
#import "FBDialog.h"


//#import "ChartBoost.h"
#import <RevMobAds/RevMobAds.h>
#import <RevMobAds/RevMobAdsDelegate.h>
#import <RevMobAds/RevMobAdvertiser.h>
//#define kInAppPurchaseProUpgradeProductId @"LoveQuotesAppProUpgrade"
//#import "RevMobAds.h"
@implementation HomeScreen
@synthesize moreItem;
@synthesize PreviousItem;
@synthesize adView;
@synthesize BGImgView;
//@synthesize toolbar,nextItem,PreviousItem,moreItem;
@synthesize textView;
@synthesize csvArray,tempArray;
@synthesize colorArray,bannerIsVisible;
@synthesize adMobclixView;
@synthesize cb;
@synthesize nextItem;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle
- (void)viewDidLoad
{
    
    [super viewDidLoad];
     [self loadStore];
  //  [NSTimer scheduledTimerWithTimeInterval:2.0 target:self selector:@selector(geRevMobBanner) userInfo:nil repeats:NO];
//    [TapjoyConnect getDisplayAdWithDelegate:self];
//	[self.view addSubview:[TapjoyConnect getDisplayAdView]];
       cb = [Chartboost sharedChartboost];  
           cb.delegate = self;
    textView.editable=FALSE;
   

    if(![[NSUserDefaults standardUserDefaults] boolForKey:@"in_app_purchase"])
    {
        NSLog(@"CSV String uriruiiuojuo" );
    self.adMobclixView = [[[MobclixAdViewiPhone_320x50 alloc] initWithFrame:CGRectMake(0, 380, 320, 50)] autorelease];
    adMobclixView.delegate = self;
    [self.view addSubview:self.adMobclixView];
    }
   
   
    csvArray=[[NSMutableArray alloc]init];
    
    NSString *resourceFileName = @"550 Weird Facts - Sheet1";
    NSString *pathToFile =[[NSBundle mainBundle] pathForResource:resourceFileName ofType: @"csv"];
    NSError *error;
    NSDictionary *dict=[[NSDictionary alloc]init ];
    NSString *fileString = [NSString stringWithContentsOfFile:pathToFile encoding:NSUTF8StringEncoding error:&error];
    
      
    CSVParser *parser = [[CSVParser alloc]initWithString:fileString separator:@"," hasHeader:NO fieldNames:[NSArray arrayWithObjects:nil]];
//    [parser parseDoubleQuote];
//    [parser parseTwoDoubleQuotes];
    
    tempArray = [parser arrayOfParsedRows] ;
   
       
    NSLog(@"CSV String%d",tempArray.count);
        
    int k=0;
    int n=tempArray.count;
    csvArray=[[NSMutableArray alloc]init];
    for(int i=0;i<tempArray.count;i++)
           
    {
        dict=[tempArray objectAtIndex:i];
        
        if(k<=n)
        {
            NSString *obj=[dict objectForKey:@"FIELD_1"];
            
            
          [csvArray insertObject:obj atIndex:i];
            //[csvArray addObject:obj];
        }
        k=k+1;
        
    }
    
    NSUInteger arraymax = [csvArray count];
    for (NSUInteger kl = 0; kl < arraymax; ++kl)
    {
      // Select a random element between i and end of array to swap with.
        int nElements = arraymax - kl;
        int km = (arc4random() % nElements) + kl;
        [csvArray exchangeObjectAtIndex:kl withObjectAtIndex:km];
        
        
    }
    
    
   // NSLog(@"csv array:%@",csvArray);
//	toolbar = [[UIToolbar alloc] initWithFrame:[self frameForToolbarAtOrientation:self.interfaceOrientation]];
//    if ([[UIToolbar class] respondsToSelector:@selector(appearance)]) {
//        [toolbar setBackgroundImage:nil forToolbarPosition:UIToolbarPositionAny barMetrics:UIBarMetricsDefault];
//        [toolbar setBackgroundImage:nil forToolbarPosition:UIToolbarPositionAny barMetrics:UIBarMetricsLandscapePhone];
//    }
//	toolbar.barStyle = UIBarStyleBlackTranslucent;
//    UIBarButtonItem *fixedLeftSpace = [[[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace target:self action:nil] autorelease];
//    fixedLeftSpace.width = 15;
//	PreviousItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemRewind target:self action:@selector(prevAction:)];	
//	nextItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFastForward target:self action:@selector(nextAction:)];
//	moreItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAction target:self action:@selector(moreAction:)];
//   UIBarButtonItem *flexSpace = [[[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:self action:nil] autorelease];
//    NSMutableArray *items = [[NSMutableArray alloc]init];
//    [items addObject:fixedLeftSpace];
//    if(csvArray.count>1)
//    {
//    [items addObject:PreviousItem];
//    [items addObject:flexSpace];
//    }
//    [items addObject:moreItem];
//    [items addObject:flexSpace];
//    if(csvArray.count>1)
//    {
//    [items addObject:nextItem];
//    }
//    [items addObject:fixedLeftSpace];
//    toolbar.items = items;
//    [items release];
//    NSLog(@"tool bar items:%@",toolbar.items);
//   [self.view addSubview:toolbar];
    
    //textView.text=[[csvArray objectAtIndex:0] objectForKey:@"text"];
  
    textView.text=[csvArray objectAtIndex:0]; 
    
    index=0;
    colorArray=[[NSMutableArray alloc]init];
//    UIColor *c1=[UIColor colorWithRed:158/255.0 green:64/255.0 blue:164/255.0 alpha:255];
    UIImage *img1=[UIImage imageNamed:@"blue.png"];
    [colorArray addObject:img1];
//    UIColor *c2=[UIColor colorWithRed:114/255.0 green:80/255.0 blue:212/255.0 alpha:255];
    UIImage *img2=[UIImage imageNamed:@"green.png"];
    [colorArray addObject:img2];
   
//    UIColor *c3=[UIColor colorWithRed:26/255.0 green:104/255.0 blue:64/255.0 alpha:255];
    UIImage *img3=[UIImage imageNamed:@"lilac.png"];
    [colorArray addObject:img3];  
//    UIColor *c4=[UIColor colorWithRed:112/255.0 green:76/255.0 blue:51/255.0 alpha:255];
    UIImage *img4=[UIImage imageNamed:@"pink.png"];
    [colorArray addObject:img4];   
//    UIColor *c5=[UIColor colorWithRed:177/255.0 green:66/255.0 blue:55/255.0 alpha:255];
    UIImage *img5=[UIImage imageNamed:@"yellow.png"];
    [colorArray addObject:img5];   
    l=0;
    [BGImgView setImage:[colorArray objectAtIndex:l]];
    if(index==0)
    {
        PreviousItem.enabled=FALSE;
    }
    
    if(![[NSUserDefaults standardUserDefaults] boolForKey:@"in_app_purchase"])
    {
     [self.view bringSubviewToFront:adMobclixView];
    }
    
    [PreviousItem setImage:[UIImage imageNamed:@"previous_pressed.png"] forState:UIControlStateHighlighted];  
    [moreItem setImage:[UIImage imageNamed:@"more_pressed.png"] forState:UIControlStateHighlighted];
    [nextItem setImage:[UIImage imageNamed:@"next_pressed.png"] forState:UIControlStateHighlighted];
  
}

- (void)adViewDidFinishLoad:(MobclixAdView*)adView
{
    NSLog(@"MobClix Launched");
}
- (void)adView:(MobclixAdView*)adView didFailLoadWithError:(NSError*)error
{
    NSLog(@"MobClix Failed");
    
    
}

- (void)viewDidAppear:(BOOL)animated {
	[super viewDidAppear:animated];
    if(![[NSUserDefaults standardUserDefaults] boolForKey:@"in_app_purchase"])
    {

	 [self.adMobclixView resumeAdAutoRefresh];
    }
}
- (void)viewWillDisappear:(BOOL)animated {
	[super viewWillDisappear:animated];
	 [self.adMobclixView pauseAdAutoRefresh];
}
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self.navigationController setNavigationBarHidden:TRUE];
}
//-(void)prevAction:(id)sender
//{
//    
//    
//          
//        if ((revIndex%5==0)&&(revIndex>0)) {
//        NSLog(@"%d",index);
//        [cb cacheInterstitial];
//        
//        //[cb showInterstitial:@"Fun Facts Full Screen Ad"];
//        NSString *fAd=[NSString stringWithFormat:@"%@ Full Screen Ad",App_Full_Name_For_Email];
//        [cb showInterstitial:fAd];
//        
//        
//       // [RevMobAds showFullscreenAdWithAppID:RevMob_Full_Screen withDelegate:nil];
//        [RevMobAds showFullscreenAdWithAppID:RevMob_Full_Screen withDelegate:self withSpecificOrientations:UIInterfaceOrientationPortrait,nil]; 
//    }
//    revIndex = revIndex+1;
//    
//    
//    index=index-1;
//    //textView.text=[[csvArray objectAtIndex:index] objectForKey:@"text"];
//     
//    textView.text=[csvArray objectAtIndex:index];
//    
//    //[BGImgView setBackgroundColor:[UIColor darkGrayColor]];
//    if(index==0)
//    {
//        PreviousItem.enabled=FALSE;
//        nextItem.enabled=TRUE;
//    }
//   
//    if(l==colorArray.count)
//    {
//        l=0;
//    }
//    elements = colorArray.count-l;
//    m = (arc4random() % elements) + l;
//    [colorArray exchangeObjectAtIndex:l withObjectAtIndex:m];
//    [BGImgView setImage:[colorArray objectAtIndex:l]];
//    l=l+1;
//}
//-(void)nextAction:(id)sender
//{
//    
//    
//    
//     if ((revIndex%5==0)&&(revIndex>0)) {
//        NSLog(@"%d",index);
//         [cb cacheInterstitial];  
//         
//         NSString *fAd=[NSString stringWithFormat:@"%@ Full Screen Ad",App_Full_Name_For_Email];
//         [cb showInterstitial:fAd];
//         
//        //[RevMobAds showFullscreenAdWithAppID:RevMob_Full_Screen withDelegate:nil];
//         [RevMobAds showFullscreenAdWithAppID:RevMob_Full_Screen withDelegate:self withSpecificOrientations:UIInterfaceOrientationPortrait,nil]; 
//         
//    }
//    revIndex = revIndex+1;
//    index=index+1;
//    //textView.text=[[csvArray objectAtIndex:index] objectForKey:@"text"];
//    textView.text=[csvArray objectAtIndex:index];
//     
//    if(index==(csvArray.count-1))
//    {
//        nextItem.enabled=FALSE;
//        PreviousItem.enabled=TRUE;
//    }
//    if(l==colorArray.count)
//    {
//        l=0;
//    }
//    elements = colorArray.count-l;
//    m = (arc4random() % elements) + l;
//    [colorArray exchangeObjectAtIndex:l withObjectAtIndex:m];
//    [BGImgView setImage:[colorArray objectAtIndex:l]];
//    l=l+1;
//    PreviousItem.enabled=TRUE;
//}
//-(void)moreAction:(id)sender
//{
//    UIActionSheet *sheet = [[UIActionSheet alloc] 
//             initWithTitle:@"" delegate:self 
//             cancelButtonTitle:@"Cancel" 
//             destructiveButtonTitle:nil 
//             otherButtonTitles:@"Share to FaceBook",@"Share to Twitter",@"E-mail",@"SMS",@"Rate This App",@"More Free Apps", nil];
//    sheet.actionSheetStyle = UIActionSheetStyleDefault;
//    [sheet showInView:self.view];
//    [sheet release];
//}
- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex 
{
    if (buttonIndex == 0)
    {
        [RevMobAds deactivateBannerAd];
        //[RevMobAds deactivateBannerAdWithAppID:RevMob_Banner_ad];
       
        //[NSTimer scheduledTimerWithTimeInterval:0.05 target:self selector:@selector(HideRevMobBanner) userInfo:nil repeats:NO];
        [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(postToFB) userInfo:nil repeats:NO];
        
        
        
    }
    else if(buttonIndex==1)
    {
        
        if ([TWTweetComposeViewController canSendTweet])
        {
            TWTweetComposeViewController *tweetSheet = 
            [[TWTweetComposeViewController alloc] init];
//            [tweetSheet setInitialText:
//             [[csvArray objectAtIndex:index] objectForKey:@"text"]];
            
            NSURL *turl = [NSURL URLWithString:MJS_APP_URL];
            [tweetSheet addURL:turl];
            
            [tweetSheet setInitialText:@"Check out this awesome free app"];
            //tweetSheet set
            //[tweetSheet addImage:galleryImageView.image];
            [self presentModalViewController:tweetSheet animated:YES];
        }
        else
        {
            UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:@"Sorry"message:@"You can't send a tweet right now, make sure your device has an internet connection and you have at least one Twitter account setup"delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
            [alertView show];
        }         
        
        
        
        
    
    }
    else if(buttonIndex==2)
    {
        MFMailComposeViewController *emailer = [[MFMailComposeViewController alloc] init];
        emailer.mailComposeDelegate = self;
        [emailer setModalPresentationStyle:UIModalPresentationFormSheet];
        
        //[emailer setSubject:@"your custom subject"];
          
        
        //NSString *tstr=[[csvArray objectAtIndex:index] objectForKey:@"text"];
        NSString *tstr=[csvArray objectAtIndex:index];
        //NSString *str=@"Check out this cool App called 'MJSTemplateApp'. I think you'll like it.";
        //NSURL *url = [NSURL URLWithString:MJS_APP_URL];
        NSString * someString = nil;
        someString = [NSString stringWithFormat:@"<a href=\"%@\">Sent from the '%@' app, download it for free here </a>",MJS_APP_URL,App_Full_Name_For_Email];
        NSString *msg=[NSString stringWithFormat:@"%@<br><br> %@",someString,tstr];
                 
        NSString *subject = @"Check this out...";
        [emailer setMessageBody:msg isHTML:YES];
        [emailer setSubject:subject];
        [self presentModalViewController:emailer animated:YES];
        [emailer release];
        
         }
    else if(buttonIndex==3)
    {
              
        
        //NSString *str=@"Check out this cool App called 'MJSTemplateApp'. I think you'll like it.";
//        NSString * someString = nil;
//        someString = (@"<a href=\"http://itunes.apple.com/app/id518571202\">Check out this awesome free app </a>");
       // NSString *tstr=[[csvArray objectAtIndex:index] objectForKey:@"text"];
        
        NSString *tstr=[csvArray objectAtIndex:index];
        NSString *msg=[NSString stringWithFormat:@"%@\nCheck out this awesome free app %@",tstr,MJS_APP_URL];
       
        [self sendSMS:msg recipientList:[NSArray arrayWithObjects:@"+1-111-222-3333", @"111-333-4444", nil]];
        
        
//        MFMessageComposeViewController *picker = [[MFMessageComposeViewController alloc] init];
//        picker.messageComposeDelegate = self;
//       // picker.wantsFullScreenLayout = NO;
//       
//        picker.body = msg;
//        [self presentModalViewController:picker animated:YES];
//        [[UIApplication sharedApplication] setStatusBarHidden:YES];
//        [picker release];        
        
           }
    else if(buttonIndex==4)
    {
        ///NSLog(@"app rating");
        [Appirater rateApp];
    }
    else if(buttonIndex==5)
    {
        
        MBProgressHUD *HUD =[MBProgressHUD showHUDAddedTo:self.view animated:TRUE];
        HUD.labelFont = [UIFont fontWithName:@"Arial" size:11];
        HUD.labelText = @"";
        
        
       // cb.delegate = self;
        [cb cacheMoreApps];
        [cb showMoreApps];
        
    }
   else if(buttonIndex==6)
   {
       

       if([[NSUserDefaults standardUserDefaults] boolForKey:@"in_app_purchase"])
       {
           NSLog(@"Already Purchased");
          [[SKPaymentQueue defaultQueue] restoreCompletedTransactions];
       }
       else
       {
           MBProgressHUD *HUD =[MBProgressHUD showHUDAddedTo:self.view animated:TRUE];
           HUD.labelFont = [UIFont fontWithName:@"Arial" size:11];
           HUD.labelText = @"Buying Pro Pack .....";
           [self purchaseProUpgrade];
       }
       
   
   }
    
   else if(buttonIndex==7)
   {
       
       if(![[NSUserDefaults standardUserDefaults] boolForKey:@"in_app_purchase"])
       {
           MBProgressHUD *HUD =[MBProgressHUD showHUDAddedTo:self.view animated:TRUE];
           HUD.labelFont = [UIFont fontWithName:@"Arial" size:11];
           HUD.labelText = @"Restore Purchases";
        [[SKPaymentQueue defaultQueue] restoreCompletedTransactions];
       }
   }
    
}

-(BOOL)shouldDisplayMoreApps
{
     [MBProgressHUD hideHUDForView:self.view animated:TRUE];  
    
    return YES;
}

- (CGRect)frameForToolbarAtOrientation:(UIInterfaceOrientation)orientation {
    CGFloat height = 44;
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone &&
        UIInterfaceOrientationIsLandscape(orientation)) height = 32;
	return CGRectMake(0, self.view.bounds.size.height - (height+30), self.view.bounds.size.width, height);
}
- (void)viewDidUnload
{
    [self setBGImgView:nil];
    [self setTextView:nil];
    [self setAdView:nil];
    [self setPreviousItem:nil];
    [self setNextItem:nil];
    [self setMoreItem:nil];
    [super viewDidUnload];
    
    [self.adMobclixView cancelAd];
	self.adMobclixView.delegate = nil;
	self.adMobclixView = nil;
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
   // return (interfaceOrientation == UIInterfaceOrientationPortrait);
    
    return NO;
}
-(void)dealloc
{
    [super dealloc];
    [moreItem release];
    [nextItem release];
    [PreviousItem release];
    adView.delegate=nil;
    [adView release];
    [textView release];
    [BGImgView release];
   // [adBanner release];
    [csvArray release];
    [colorArray release];
    [self.adMobclixView cancelAd];
	self.adMobclixView.delegate = nil;
	self.adMobclixView = nil;
    [[SKPaymentQueue defaultQueue] removeTransactionObserver:self];
    
}
- (void)bannerViewDidLoadAd:(ADBannerView *)banner
{
    
    if (!self.bannerIsVisible)
    {NSLog(@"11");
        [UIView beginAnimations:@"animateAdBannerOn" context:NULL];
        // banner is invisible now and moved out of the screen on 50 px
       // banner.frame = CGRectOffset(banner.frame,0, 271);
        [UIView commitAnimations];
        self.bannerIsVisible = YES;
    }
}

- (void)bannerView:(ADBannerView *)banner didFailToReceiveAdWithError:(NSError *)error
{
   /// NSLog(@"error%@",error);
    if (self.bannerIsVisible)
    {
        [UIView beginAnimations:@"animateAdBannerOff" context:NULL];
        // banner is visible and we move it out of the screen, due to connection issue
       // banner.frame = CGRectOffset(banner.frame, 0, 270);
        [UIView commitAnimations];
        self.bannerIsVisible = NO;
    }
}
//- (void)willRotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:(NSTimeInterval)duration
//{
//    if (UIInterfaceOrientationIsLandscape(toInterfaceOrientation))
//        adView.currentContentSizeIdentifier = ADBannerContentSizeIdentifier480x32;
//    else
//        adView.currentContentSizeIdentifier = ADBannerContentSizeIdentifier320x50;
//}
//#pragma mark GADRequest generation
//
//// Here we're creating a simple GADRequest and whitelisting the simulator
//// and two devices for test ads. You should request test ads during development
//// to avoid generating invalid impressions and clicks.
//- (GADRequest *)createRequest {
//    GADRequest *request = [GADRequest request];
//    
//    //Make the request for a test ad
//    request.testDevices = [NSArray arrayWithObjects:
//                           GAD_SIMULATOR_ID,                               // Simulator
//                           nil];
//    
//    return request;
//}
//
//#pragma mark GADBannerViewDelegate impl
//
//// Since we've received an ad, let's go ahead and set the frame to display it.
//- (void)adViewDidReceiveAd:(GADBannerView *)adView {
//    NSLog(@"Received ad");
//    
//    [UIView animateWithDuration:1.0 animations:^ {
//        adView.frame = CGRectMake(0.0,
//                                  420.0,
//                                  adView.frame.size.width,
//                                  adView.frame.size.height);
//        
//    }];
//}
//
//- (void)adView:(GADBannerView *)view
//didFailToReceiveAdWithError:(GADRequestError *)error {
//    NSLog(@"Failed to receive ad with error: %@", [error localizedFailureReason]);
//}
#pragma mark Mail Compose Delegate


- (IBAction)Prev_pressed:(id)sender
{
 
  
    if ((revIndex%5==0)&&(revIndex>0))
    {
        NSLog(@"%d",index);
        [cb cacheInterstitial];
        
        //[cb showInterstitial:@"Fun Facts Full Screen Ad"];
        if(![[NSUserDefaults standardUserDefaults] boolForKey:@"in_app_purchase"])
        {
        NSString *fAd=[NSString stringWithFormat:@"%@ Full Screen Ad",App_Full_Name_For_Email];
        [cb showInterstitial:fAd];
         [FlurryAds fetchAndDisplayAdForSpace:@"INTERSTITIAL_MAIN_VC" view:self.view size:FULLSCREEN];
        
        // [RevMobAds showFullscreenAdWithAppID:RevMob_Full_Screen withDelegate:nil];
           // [RevMobAds showFullscreenAdWithDelegate:self
                      //     withSpecificOrientations:UIInterfaceOrientationPortrait, nil];
            RevMobAds *revmob = [RevMobAds revMobAds];
            //  RevMobFullscreen *fullscreen = [revmob fullscreenWithPlacementId:RevMob_Full_Screen];
            [revmob showFullscreen];
        }
    }
    revIndex = revIndex+1;
    
    
    index=index-1;
    //textView.text=[[csvArray objectAtIndex:index] objectForKey:@"text"];
    
    textView.text=[csvArray objectAtIndex:index];
    
    //[BGImgView setBackgroundColor:[UIColor darkGrayColor]];
    if(index==0)
    {
        PreviousItem.enabled=FALSE;
        nextItem.enabled=TRUE;
    }
    
    if(l==colorArray.count)
    {
        l=0;
    }
    elements = colorArray.count-l;
    m = (arc4random() % elements) + l;
    [colorArray exchangeObjectAtIndex:l withObjectAtIndex:m];
    [BGImgView setImage:[colorArray objectAtIndex:l]];
    l=l+1;

}

- (IBAction)More_Pressed:(id)sender 
{

    if([[NSUserDefaults standardUserDefaults] boolForKey:@"in_app_purchase"])
    {
        NSLog(@"Already Purchased");
        UIActionSheet *sheet = [[UIActionSheet alloc] 
                                initWithTitle:@"" delegate:self 
                                cancelButtonTitle:@"Cancel" 
                                destructiveButtonTitle:nil 
                                otherButtonTitles:@"Share to FaceBook",@"Share to Twitter",@"E-mail",@"SMS",@"Rate This App",@"More Free Apps",@"Restore Purchases", nil];
        sheet.actionSheetStyle = UIActionSheetStyleDefault;
        [sheet showInView:self.view];
        [sheet release];
    }
  else
  {
      NSLog(@"else");
    UIActionSheet *sheet = [[UIActionSheet alloc] 
                            initWithTitle:@"" delegate:self 
                            cancelButtonTitle:@"Cancel" 
                            destructiveButtonTitle:nil 
                            otherButtonTitles:@"Share to FaceBook",@"Share to Twitter",@"E-mail",@"SMS",@"Rate This App",@"More Free Apps",@"Remove Ads", @"Restore Purchases",nil];
    sheet.actionSheetStyle = UIActionSheetStyleDefault;
    [sheet showInView:self.view];
    [sheet release];
  }

}

- (IBAction)Next_Pressed:(id)sender
{
 
    if ((revIndex%5==0)&&(revIndex>0)) {
        NSLog(@"%d",index);
        if(![[NSUserDefaults standardUserDefaults] boolForKey:@"in_app_purchase"])
        {
          
        
        NSString *fAd=[NSString stringWithFormat:@"%@ Full Screen Ad",App_Full_Name_For_Email];
            [cb cacheInterstitial:fAd];
        [cb showInterstitial:fAd];
        
             [FlurryAds fetchAndDisplayAdForSpace:@"INTERSTITIAL_MAIN_VC" view:self.view size:FULLSCREEN];
            
        //[RevMobAds showFullscreenAdWithAppID:RevMob_Full_Screen withDelegate:nil];
          //  [RevMobAds showFullscreenAdWithDelegate:self
                        //   withSpecificOrientations:UIInterfaceOrientationPortrait, nil];
            RevMobAds *revmob = [RevMobAds revMobAds];
            //  RevMobFullscreen *fullscreen = [revmob fullscreenWithPlacementId:RevMob_Full_Screen];
            [revmob showFullscreen];

        }
        
    }
    revIndex = revIndex+1;
    index=index+1;
    //textView.text=[[csvArray objectAtIndex:index] objectForKey:@"text"];
    textView.text=[csvArray objectAtIndex:index];
    
    if(index==(csvArray.count-1))
    {
        nextItem.enabled=FALSE;
        PreviousItem.enabled=TRUE;
    }
    if(l==colorArray.count)
    {
        l=0;
    }
    elements = colorArray.count-l;
    m = (arc4random() % elements) + l;
    [colorArray exchangeObjectAtIndex:l withObjectAtIndex:m];
    [BGImgView setImage:[colorArray objectAtIndex:l]];
    l=l+1;
    PreviousItem.enabled=TRUE;    

}

- (void)sendSMS:(NSString *)bodyOfMessage recipientList:(NSArray *)recipients
{
    MFMessageComposeViewController *controller = [[[MFMessageComposeViewController alloc] init] autorelease];
    if([MFMessageComposeViewController canSendText])
    {
        controller.body = bodyOfMessage;    
        controller.recipients = nil;
        controller.messageComposeDelegate = self;
        [self presentModalViewController:controller animated:YES];
        [[UIApplication sharedApplication] setStatusBarHidden:YES];
    }    
}
- (void)mailComposeController:(MFMailComposeViewController*)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError*)error {
    if (result == MFMailComposeResultFailed) {
		UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:NSLocalizedString(@"Email", nil)message:NSLocalizedString(@"Email failed to send. Please try again.", nil) delegate:nil cancelButtonTitle:NSLocalizedString(@"Dismiss", nil) otherButtonTitles:nil] autorelease];
		[alert show];
    }
	[self dismissModalViewControllerAnimated:YES];
}
//-(void)messageComposeViewController:(MFMessageComposeViewController *)controller didFinishWithResult:(MessageComposeResult)result
//{
////    if(result==MessageComposeResultFailed)
////    {
////        UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:NSLocalizedString(@"SMS", nil)message:NSLocalizedString(@"Message failed to send. Please try again.", nil) delegate:nil cancelButtonTitle:NSLocalizedString(@"Dismiss", nil) otherButtonTitles:nil] autorelease];
////            [alert show];
////    }
//    [self dismissModalViewControllerAnimated:YES];
//    
//
//}
- (void)messageComposeViewController:(MFMessageComposeViewController *)controller didFinishWithResult:(MessageComposeResult)result
{
    [self dismissModalViewControllerAnimated:YES];
    
    if (result == MessageComposeResultCancelled)
        NSLog(@"Message cancelled");
        else if (result == MessageComposeResultSent)
            NSLog(@"Message sent"); 
            else 
                NSLog(@"Message failed");  
        
}
//-(CLLocation*)findCurrentLocation
//{
//    //BOOL locationServicesEnabled;
//    CLLocationManager *locationManager = [CLLocationManager new];
//    if ([locationManager respondsToSelector:@selector(locationServicesEnabled)])
//    {
//        //locationServicesEnabled = [locationManager locationServicesEnabled];
//        locationManager.delegate = self; 
//        locationManager.desiredAccuracy = kCLLocationAccuracyBest; 
//        locationManager.distanceFilter = kCLDistanceFilterNone; 
//        [locationManager startUpdatingLocation];
//    }
//    else
//    {
//        //locationServicesEnabled = locationManager.locationServicesEnabled;
//    }
//    CLLocation *location = [locationManager location];
//    //CLLocationCoordinate2D coordinate = [location coordinate];
//    return location;
//    
//}
-(void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex
{
    if (buttonIndex==1) 
    {
        NSLog(@"alertView");
       // [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(postToFB) userInfo:nil repeats:NO];
    }
    else{
        //        [self performSelector:@selector(postToFB)];
        
    }
}

-(void) askForFacebook
{
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Share to Facebook" message:@"Do you want to share this text on Facebook" delegate:self cancelButtonTitle:@"NO" otherButtonTitles:@"Yes", nil];
    
    [alert show];
    [alert release];
}


-(void) postToFB
{
          
  
     
   // NSString *tstr=[[csvArray objectAtIndex:index] objectForKey:@"text"];
    NSString *tstr=[csvArray objectAtIndex:index];
    
    FBFeedPost *post = [[FBFeedPost alloc] initWithLinkPath:MJS_APP_URL caption:@"" msg:tstr];
	[post publishPostWithDelegate:self];
    [WToast showWithText:@"Please wait while it's being shared..."];

   
       
}


//-(IBAction) btnFBTap:(id)sender
//{
//    
//}
//- (void)dialog:(FBDialog*)dialog didFailWithError:(NSError *)error
//{
//    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Yo" message:@"Yo" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
//    [alert show];
//    [alert release];
//    
//    NSLog(@"%@",error);
//}


-(void)failedToPublishPost:(FBFeedPost *)_post
{
    ///NSLog(@"failed");
}

-(void)finishedPublishingPost:(FBFeedPost *)_post
{
    
      [WToast showWithText:@"Successfully shared"];
 
    
    ///NSLog(@"published, YO!");
}
-(void)getDidLoadRevMob
{
    RevMobAds *revmob = [RevMobAds revMobAds];
    RevMobFullscreen *fullscreen = [revmob fullscreenWithPlacementId:RevMob_Full_Screen];
    [fullscreen showAd];

    
}
-(void)HideRevMobBanner
{
    
    
    
  //  [RevMobAds hideBannerAd];
    
    
}


#pragma mark Tapjoy Banner Ads Delegate Methods
/*- (void)initVideoAds
{
	[TapjoyConnect initVideoAdWithDelegate:self];
}


- (void)videoAdBegan
{
	NSLog(@"Video Ad Began Playing");
}


- (void)videoAdClosed
{
	NSLog(@"Video Ad View Closed");	
}

- (void)didReceiveAd:(TJCAdView*)adViews
{
	adViews.frame = CGRectMake(0, 0, 320, 50);
}


- (void)didFailWithMessage:(NSString*)msg
{
	NSLog(@"No Tapjoy Banner Ads available");
}


- (NSString*)adContentSize
{
	return TJC_AD_BANNERSIZE_320X50;
}


- (BOOL)shouldRefreshAd
{
	return NO;
}
*/
-(void)geRevMobBanner
{
      
   
   //  [RevMobAds showBannerAdWithAppID:RevMob_Banner_ad withFrame:CGRectMake(0.0f, 380.0f, 320.0f, 50.0f) withDelegate:self withSpecificOrientations:UIInterfaceOrientationPortrait, nil];
 
    
}

 

//- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex 
//{
//    
//    switch (buttonIndex) {
//        case 0:
//            [self.navigationController popToRootViewControllerAnimated:YES];
//            
//            break;
//        case 1:
//            NSLog(@"buy tap");
//            MBProgressHUD *HUD =[MBProgressHUD showHUDAddedTo:self.view animated:TRUE];
//            HUD.labelFont = [UIFont fontWithName:@"Arial" size:11];
//            HUD.labelText = @"Buying Pro Pack .....";
//            [self purchaseProUpgrade];
//            break;
//        default:
//            break;
//    }
//    
//    
//}
- (void)revmobUserClickedInTheAd
{
//    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Yo" message:@"Clicked" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
//    [alert show];
//    [alert release];
//    
}
#pragma mark -
#pragma mark SKProductsRequestDelegate methods

- (void)productsRequest:(SKProductsRequest *)request didReceiveResponse:(SKProductsResponse *)response
{
    
    NSLog(@"1");
    NSArray *products = response.products;
    proUpgradeProduct = [products count] == 1 ? [[products objectAtIndex:0] retain] : nil;
    if (proUpgradeProduct)
    {
        NSLog(@"Product title: %@" , proUpgradeProduct.localizedTitle);
        NSLog(@"Product description: %@" , proUpgradeProduct.localizedDescription);
        NSLog(@"Product price: %@" , proUpgradeProduct.price);
        NSLog(@"Product id: %@" , proUpgradeProduct.productIdentifier);
    }
    
    for (NSString *invalidProductId in response.invalidProductIdentifiers)
    {
        NSLog(@"Invalid product id: %@" , invalidProductId);
    }
    
    // finally release the reqest we alloc/init’ed in requestProUpgradeProductData
    [productsRequest release];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:kInAppPurchaseManagerProductsFetchedNotification object:self userInfo:nil];
    
} 

#pragma -
#pragma Public methods

//
// call this method once on startup
//
- (void)loadStore
{
    
    // restarts any purchases if they were interrupted last time the app was open
    [[SKPaymentQueue defaultQueue] addTransactionObserver:self];
    
    // get the product description (defined in early sections)
     [self requestProUpgradeProductData];
}

//
// call this before making a purchase
//
- (BOOL)canMakePurchases
{
    return [SKPaymentQueue canMakePayments];
}

//
// kick off the upgrade transaction
//
- (void)purchaseProUpgrade
{
    NSLog(@"purchaseProUpgrade");
    //progressHud.hidden=FALSE;
    //[progressHud startAnimating];
    SKPayment *payment = [SKPayment paymentWithProductIdentifier:kInAppPurchaseProUpgradeProductId];
    [[SKPaymentQueue defaultQueue] addTransactionObserver:self];
    [[SKPaymentQueue defaultQueue] addPayment:payment];
}

#pragma -
#pragma Purchase helpers

//
// saves a record of the transaction by storing the receipt to disk
//
- (void)recordTransaction:(SKPaymentTransaction *)transaction
{
    NSLog(@"recordTransaction");
    if ([transaction.payment.productIdentifier isEqualToString:kInAppPurchaseProUpgradeProductId])
    {
        // save the transaction receipt to disk
        [[NSUserDefaults standardUserDefaults] setValue:transaction.transactionReceipt forKey:@"proUpgradeTransactionReceipt" ];
        [[NSUserDefaults standardUserDefaults] synchronize];
    }
}

//
// enable pro features
//
- (void)provideContent:(NSString *)productId
{
    NSLog(@"provideContent");
    if ([productId isEqualToString:kInAppPurchaseProUpgradeProductId])
    {
        NSLog(@"provideContent: upgraded! Yo!");
        // enable the pro features
        [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"isProUpgradePurchased" ];
        [[NSUserDefaults standardUserDefaults] synchronize];    }
}

//
// removes the transaction from the queue and posts a notification with the transaction result
//
- (void)finishTransaction:(SKPaymentTransaction *)transaction wasSuccessful:(BOOL)wasSuccessful
{
    NSLog(@"finishTransaction");
    [MBProgressHUD hideHUDForView:self.view animated:TRUE];
    // remove the transaction from the payment queue.
    [[SKPaymentQueue defaultQueue] finishTransaction:transaction];
    
    NSDictionary *userInfo = [NSDictionary dictionaryWithObjectsAndKeys:transaction, @"transaction" , nil];
    if (wasSuccessful)
    {
        NSLog(@"finishTransaction: wasSuccessfull");
        // send out a notification that we’ve finished the transaction
        [[NSNotificationCenter defaultCenter] postNotificationName:kInAppPurchaseManagerTransactionSucceededNotification object:self userInfo:userInfo];
    }
    else
    {
        NSLog(@"finishTransaction: wasNotSuccessfull");
        // send out a notification for the failed transaction
        [[NSNotificationCenter defaultCenter] postNotificationName:kInAppPurchaseManagerTransactionFailedNotification object:self userInfo:userInfo];
    }
}

//
// called when the transaction was successful
//
- (void)completeTransaction:(SKPaymentTransaction *)transaction
{
    NSLog(@"completeTransaction");
    [self recordTransaction:transaction];
    [self provideContent:transaction.payment.productIdentifier];
    [self finishTransaction:transaction wasSuccessful:YES];
    [self proPackPurchased];
}

//
// called when a transaction has been restored and and successfully completed
//
- (void)restoreTransaction:(SKPaymentTransaction *)transaction
{
    NSLog(@"restoreTransaction");
    [self recordTransaction:transaction.originalTransaction];
    [self provideContent:transaction.originalTransaction.payment.productIdentifier];
    [self finishTransaction:transaction wasSuccessful:YES];
}
-(void)paymentQueueRestoreCompletedTransactionsFinished:(SKPaymentQueue *)queue 
{
    [MBProgressHUD hideHUDForView:self.view animated:TRUE];
    [WToast showWithText:@"Successfully Restored"];
     [RevMobAds deactivateBannerAd];

}
- (void)paymentQueue:(SKPaymentQueue*)queue restoreCompletedTransactionsFailedWithError:(NSError*)error
{
    [MBProgressHUD hideHUDForView:self.view animated:TRUE];
    NSLog(@"Error %@",error);
}
//
// called when a transaction has failed
//
- (void)failedTransaction:(SKPaymentTransaction *)transaction
{
    [MBProgressHUD hideHUDForView:self.view animated:TRUE];
    NSLog(@"failedTransaction");
    if (transaction.error.code != SKErrorPaymentCancelled)
    {
        // error!
        NSLog(@"failedTransaction: SKErrorPaymentCancelled");
        [self finishTransaction:transaction wasSuccessful:NO];
        
    }
    else
    {
        NSLog(@"failedTransaction: NOT SKErrorPaymentCancelled");
        // this is fine, the user just cancelled, so don’t notify
        [[SKPaymentQueue defaultQueue] finishTransaction:transaction];
      
        
    }
}

#pragma mark -
#pragma mark SKPaymentTransactionObserver methods

//
// called when the transaction status is updated
//
- (void)paymentQueue:(SKPaymentQueue *)queue updatedTransactions:(NSArray *)transactions
{
    
    //[progressHud stopAnimating];
    
    NSLog(@"paymentQueue:(SKPaymentQueue *)queue updatedTransactions");
    for (SKPaymentTransaction *transaction in transactions)
    {
        
        switch (transaction.transactionState)
        {
            case SKPaymentTransactionStatePurchased:
                [self completeTransaction:transaction];
                NSLog(@"SKPaymentTransactionStatePurchased");
                
                [RevMobAds deactivateBannerAd];
               [RevMobAds releaseFullscreenAd];

                break;
            case SKPaymentTransactionStateFailed:
                [self failedTransaction:transaction];
                NSLog(@"SKPaymentTransactionStateFailed");
                break;
            case SKPaymentTransactionStateRestored:
                [self restoreTransaction:transaction];
                NSLog(@"SKPaymentTransactionStateRestored");
                [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"in_app_purchase"];
                [[NSUserDefaults standardUserDefaults] synchronize];
               
               // [RevMobAds hideBannerAdWithAppID:RevMob_Full_Screen];
                break;
            default:
                break;
        }
    }
} 

// InAppPurchaseManager.m

- (void)requestProUpgradeProductData
{
    NSLog(@"request");
    NSSet *productIdentifiers = [NSSet setWithObject:kInAppPurchaseProUpgradeProductId ];
    productsRequest = [[SKProductsRequest alloc] initWithProductIdentifiers:productIdentifiers];
    productsRequest.delegate = self;
    [productsRequest start];
    
    // we will release the request object in the delegate callback
}



-(void) proPackPurchased
{   
    NSLog(@"last offer");
    [MBProgressHUD hideHUDForView:self.view animated:YES];
    [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"in_app_purchase"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
     [RevMobAds deactivateBannerAd];
    [RevMobAds releaseFullscreenAd];
   // [RevMobAds hideBannerAdWithAppID:RevMob_Full_Screen];
}    


@end
