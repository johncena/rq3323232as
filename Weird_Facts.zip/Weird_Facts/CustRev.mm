//
//  CustRev.cpp
//  MJSAppTemplate
//
//  Created by Pairroxz-Ranjeet on 13/07/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

//#include <iostream>
#import "CustRev.h"
@implementation CustRev

- (void) revmobAdDidReceive {
    NSLog(@"[RevMob Sample App] Ad loaded.");
}

- (void) revmobAdDidFailWithError:(NSError *)error {
    NSLog(@"[RevMob Sample App] Ad failed.");
}

- (void) revmobUserClickedInTheCloseButton {
    NSLog(@"[RevMob Sample App] User clicked in the close button");
}

- (void) revmobUserClickedInTheAd {
    NSLog(@"[RevMob Sample App] User clicked in the Ad");
}
@end
