//
//  MoreFreeAppScreen.h
//  MJSAppTemplate
//
//  Created by Pairroxz on 17/01/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MoreFreeAppScreen : UIViewController

- (IBAction)Back:(id)sender;
@property (retain, nonatomic) IBOutlet UINavigationBar *navBar;
@property (retain, nonatomic) IBOutlet UIWebView *webView;
@end
