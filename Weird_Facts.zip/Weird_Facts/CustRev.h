//
//  CustRev.h
//  MJSAppTemplate
//
//  Created by Pairroxz-Ranjeet on 13/07/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//
//
//#ifndef MJSAppTemplate_CustRev_h
//#define MJSAppTemplate_CustRev_h
//
//
//
//#endif
#import <Foundation/Foundation.h>
//#import <RevMobAds.framework>
#import <RevMobAds/RevMobAdsDelegate.h>
//#import<Rev>
@interface CustRev : NSObject<RevMobAdsDelegate>
@end