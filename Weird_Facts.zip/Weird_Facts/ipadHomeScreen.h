//
//  ipadHomeScreen.h
//  MJSAppTemplate
//
//  Created by Pairroxz on 15/01/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//
#import "AppDelegate.h"
#import <UIKit/UIKit.h>
#import <iAd/iAd.h>
#import <StoreKit/StoreKit.h>
#import <CoreLocation/CoreLocation.h>
#import <SystemConfiguration/SystemConfiguration.h>
#import <MessageUI/MessageUI.h>
#import <AudioToolbox/AudioToolbox.h>
#import "Appirater.h"
#import "FBFeedPost.h"
#import <Twitter/Twitter.h>
#import "CSVParser.h"
#import <RevMobAds/RevMobAds.h>
#import <RevMobAds/RevMobAdvertiser.h>
#import <RevMobAds/RevMobAdsDelegate.h>
//#import "RevMobAds.h"
//#import "RevMobAdsDelegate.h"
#import "Mobclix.h"
#import "MobclixAds.h"
#import "MobclixAdView.h"
#import <QuartzCore/QuartzCore.h>
//#import "ChartBoost.h"
#import "Chartboost.h"
//#import "GADBannerView.h"
//#import "GADRequest.h"
//#import "GADBannerViewDelegate.h"
#import "Flurry.h"
#import "FlurryAdDelegate.h"
#import "FlurryAds.h"
#define kInAppPurchaseManagerProductsFetchedNotification @"kInAppPurchaseManagerProductsFetchedNotification" 
#define kInAppPurchaseManagerTransactionFailedNotification @"kInAppPurchaseManagerTransactionFailedNotification"
#define kInAppPurchaseManagerTransactionSucceededNotification @"kInAppPurchaseManagerTransactionSucceededNotification"
@interface ipadHomeScreen : UIViewController<UIActionSheetDelegate,MFMailComposeViewControllerDelegate,MFMessageComposeViewControllerDelegate,CLLocationManagerDelegate,UIWebViewDelegate,UIPopoverControllerDelegate,ADBannerViewDelegate,FBFeedPostDelegate,UIAlertViewDelegate,RevMobAdsDelegate,MobclixAdViewDelegate,ChartboostDelegate,SKProductsRequestDelegate,SKPaymentTransactionObserver,FlurryAdDelegate>
{
   @private MobclixAdView *adMobclixView;
    NSInteger count;
    NSInteger index;
    NSInteger revIndex;
    NSInteger l;
    int elements;
    int m;
     BOOL bannerIsVisible;
    UIActionSheet *sheet;
    SKProduct *proUpgradeProduct;
    SKProductsRequest *productsRequest;
}
-(void) proPackPurchased;
- (void)purchaseProUpgrade;
- (void)loadStore;
- (void)requestProUpgradeProductData;
@property (nonatomic,assign) BOOL bannerIsVisible;
//@property(retain,nonatomic)UIBarButtonItem *nextItem;
@property (retain, nonatomic) IBOutlet UIButton *nextItem;

//@property (nonatomic, retain) ChartBoost *cb;
@property (retain, nonatomic) IBOutlet UIButton *PreviousItem;
@property (retain,nonatomic) Chartboost *cb;
@property (retain,nonatomic) RevMobAds *rMob;
@property (retain, nonatomic) IBOutlet ADBannerView *adView;
@property (retain, nonatomic) IBOutlet UIButton *moreItem;

- (IBAction)More_Pressed:(id)sender;
- (IBAction)Next_Pressed:(id)sender;
- (IBAction)Previous_pressed:(id)sender;
@property (retain, nonatomic) IBOutlet UITextView *textView;
@property(retain,nonatomic)NSMutableArray *csvArray;
@property(retain,nonatomic)NSArray *tempArray;
@property(retain,nonatomic)NSMutableArray *colorArray;
@property(nonatomic,retain) MobclixAdView *adMobclixView;
//@property(retain,nonatomic)UIPopoverController *popOverView;
- (CGRect)frameForToolbarAtOrientation:(UIInterfaceOrientation)orientation;
- (void)sendSMS:(NSString *)bodyOfMessage recipientList:(NSArray *)recipients;
-(void)prevAction:(id)sender;
-(void)nextAction:(id)sender;
-(void)moreAction:(id)sender;
//-(CLLocation*)findCurrentLocation;
@property (retain, nonatomic) IBOutlet UIImageView *BGImgView;
//@property(nonatomic, retain) GADBannerView *adBanner;
//- (GADRequest *)createRequest;
-(void) askForFacebook;
-(void) postToFB;
//-(void)hideHudd;
-(void)getDidLoadRevMob;
-(void)geRevMobBanner;
-(void)HideRevMobBanner;
@end
