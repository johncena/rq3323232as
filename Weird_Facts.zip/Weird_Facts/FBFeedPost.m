//
//  FBFeedPost.m
//  Facebook Demo
//
//  Created by Andy Yanok on 3/1/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "FBFeedPost.h"


@implementation FBFeedPost
@synthesize message, caption, image, url, postType, delegate;

- (id) initWithLinkPath:(NSString*) _url caption:(NSString*) _caption {
	self = [super init];
	if (self) {
		postType = FBPostTypeLink;
		url = [_url retain];
		caption = [_caption retain];
	}
	return self;
}

- (id) initWithLinkPath:(NSString*) _url caption:(NSString*) _caption msg:(NSString*) _msg {
	self = [super init];
	if (self) {
		postType = FBPostTypeLink;
		url = [_url retain];
		caption = [_caption retain];
        message = [_msg retain];
	}
	return self;
}

- (id) initWithPostMessage:(NSString*) _message {
	self = [super init];
	if (self) {
		postType = FBPostTypeStatus;
		message = [_message retain];
	}
	return self;
}

- (id) initWithPhoto:(UIImage*) _image name:(NSString*) _name {
	self = [super init];
	if (self) {
		postType = FBPostTypePhoto;
		image = [_image retain];
		//caption = [_image retain];
	}
	return self;
}

- (void) publishPostWithDelegate:(id) _delegate {
	
	//store the delegate incase the user needs to login
	self.delegate = _delegate;
	
	// if the user is not currently logged in begin the session
	BOOL loggedIn = [[FBRequestWrapper defaultManager] isLoggedIn];
	if (!loggedIn) {
       		[[FBRequestWrapper defaultManager] FBSessionBegin:self];
	}
	else {
       		[self getFacebookName];
	}	
}

- (void)getFacebookName {
    isLoadingName = YES;
    [[FBRequestWrapper defaultManager] getFBRequestWithGraphPath:@"me" andDelegate:self];
}

//#pragma mark FBRequestDelegate methods
//
//- (void)request:(FBRequest*)request didLoad:(id)result {
//	if ([request.method isEqualToString:@"facebook.fql.query"]) {
//		NSArray* users = result;
//		NSDictionary* user = [users objectAtIndex:0];
//		NSString* name = [user objectForKey:@"name"];
//		self.facebookName = name;		
//		_logoutButton.hidden = NO;
//		[_logoutButton setTitle:[NSString stringWithFormat:@"Facebook: Logout as %@", name] forState:UIControlStateNormal];
//		if (_posting) {
//			[self postToWall];
//			_posting = NO;
//		}
//	}
//}


-(void) postStatus
{
    NSMutableDictionary *params = [[[NSMutableDictionary alloc] init] autorelease];
    
    //Need to provide POST parameters to the Facebook SDK for the specific post type
    NSString *graphPath = @"me/feed";
    
    switch (postType) {
        case FBPostTypeLink:
        {
            [params setObject:@"link" forKey:@"type"];
            [params setObject:self.url forKey:@"link"];
            [params setObject:self.caption forKey:@"description"];
            [params setObject:self.message forKey:@"message"];
            
            break;
        }
        case FBPostTypeStatus:
        {
            [params setObject:@"status" forKey:@"type"];
            NSString *msg = (NSString*)[NSString stringWithFormat:@"%@ %@",[[NSUserDefaults standardUserDefaults] objectForKey:@"Username"], self.message];
            [params setObject:msg forKey:@"message"];
            break;
        }
        case FBPostTypePhoto:
        {
            graphPath = @"me/photos";
            [params setObject:self.image forKey:@"source"];
            [params setObject:self.caption forKey:@"message"];
            break;
        }
        default:
            break;
    }
    
    [[FBRequestWrapper defaultManager] sendFBRequestWithGraphPath:graphPath params:params andDelegate:self];
}

#pragma mark -
#pragma mark FacebookSessionDelegate

- (void)fbDidLogin {
	[[FBRequestWrapper defaultManager] setIsLoggedIn:YES];
	
	//after the user is logged in try to publish the post
	[self publishPostWithDelegate:self.delegate];
}

- (void)fbDidNotLogin:(BOOL)cancelled {
	[[FBRequestWrapper defaultManager] setIsLoggedIn:NO];
   
    
     [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(geRevMobBanner) userInfo:nil repeats:NO];

}

#pragma mark -
#pragma mark FBRequestDelegate

- (void)request:(FBRequest *)request didFailWithError:(NSError *)error {
	[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
	NSLog(@"ResponseFailed: %@", error);
	NSLog(@"---It's failed--");
	if ([self.delegate respondsToSelector:@selector(failedToPublishPost:)])
		[self.delegate failedToPublishPost:self];
}

- (void)request:(FBRequest *)request didLoad:(id)result {
	[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];

    if (isLoadingName) {
        if ([result isKindOfClass:[NSDictionary class]]) {
            NSDictionary* hash = result;
            NSString *username = (NSString*)[hash valueForKey:@"name"];
            NSLog(@"username is: %@", username);
            [[NSUserDefaults standardUserDefaults] setObject:username forKey:@"Username"];
            [[NSUserDefaults standardUserDefaults] synchronize];
            isLoadingName = NO;
            [self postStatus];
        }
    }
    else
    {
        
        NSLog(@"Published, YO!");
        
        [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(geRevMobBanner) userInfo:nil repeats:NO];
        
       
        
    }
    
	if ([self.delegate respondsToSelector:@selector(finishedPublishingPost:)])
		[self.delegate finishedPublishingPost:self];
}
-(void)geRevMobBanner
{
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone)
    {
        //[RevMobAds showBannerAdWithAppID:RevMob_Banner_ad withFrame:CGRectMake(0.0f, 430.0f, 320.0f, 50.0f) withDelegate:self];
        
        [RevMobAds showBannerAdWithFrame:CGRectMake(0.0f, 380.0f, 320.0f, 50.0f) withDelegate:self];
    }
    else
    {
        NSLog(@",--Ipad YO!");
       // [RevMobAds showBannerAdWithAppID:RevMob_Banner_ad withFrame:CGRectMake(0.0f, 934.0f, 768.0f, 90.0f) withDelegate:self];
                
       [RevMobAds showBannerAdWithFrame:CGRectMake(0.0f, 830.0f, 768.0f, 90.0f) withDelegate:self];;
        
    }
}

// FbSession Delegate methods




/**
 * Called after the access token was extended. If your application has any
 * references to the previous access token (for example, if your application
 * stores the previous access token in persistent storage), your application
 * should overwrite the old access token with the new one in this method.
 * See extendAccessToken for more details.
 */
- (void)fbDidExtendToken:(NSString*)accessToken
               expiresAt:(NSDate*)expiresAt
{
}
/**
 * Called when the user logged out.
 */
- (void)fbDidLogout
{
    
}

/**
 * Called when the current session has expired. This might happen when:
 *  - the access token expired
 *  - the app has been disabled
 *  - the user revoked the app's permissions
 *  - the user changed his or her password
 */



- (void)fbSessionInvalidated
{
    NSLog(@"Session Invalidated");
}
- (void) dealloc {
	self.delegate = nil;
	[url release], url = nil;
	[message release], message = nil;
	[caption release], caption = nil;
	[image release], image = nil;
	[super dealloc];
}

@end
