//
//  AppDelegate.m
//  MJSAppTemplate
//
//  Created by Pairroxz on 15/01/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "AppDelegate.h"
#import "HomeScreen.h"
#import "ipadHomeScreen.h"
#import "Mobclix.h"
#import <RevMobAds/RevMobAds.h>
#import <RevMobAds/RevMobAdvertiser.h>
//#import "ChartBoost.h"

@implementation AppDelegate

@synthesize window = _window;
@synthesize cb;
@synthesize managedObjectContext = __managedObjectContext;
@synthesize managedObjectModel = __managedObjectModel;
@synthesize persistentStoreCoordinator = __persistentStoreCoordinator;
@synthesize pushManager;
@synthesize nvct;
- (void)dealloc
{
    [_window release];
    [__managedObjectContext release];
    [__managedObjectModel release];
    [__persistentStoreCoordinator release];
    self.pushManager = nil;
    [super dealloc];
}

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    
    cb = [Chartboost sharedChartboost];
    cb.appId = ChartBoost_APP_ID_ads;
    cb.appSignature = ChartBoost_APP_Signature_ads;
    cb.delegate = self;
    [cb cacheInterstitial];
    [cb cacheMoreApps];
    [cb startSession];
    
     [Flurry startSession:FlurryIphone_APP_ID];
    
         [RevMobAds startSessionWithAppID:RevMobMain_ID testingMode:RevMobAdsTestingModeOff];
   // [RevMobAds startSessionWithAppID:RevMob_Banner_ad testingMode:RevMobAdsTestingModeOff];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(tjcConnectSuccess:) name:TJC_CONNECT_SUCCESS object:nil];
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(tjcConnectFail:) name:TJC_CONNECT_FAILED object:nil];
	
	// NOTE: This must be replaced by your App Id. It is Retrieved from the Tapjoy website, in your account.
	[TapjoyConnect requestTapjoyConnect:TapJoy_ID secretKey:TapJoy_SecretKey];
  //  [TapjoyConnect requestTapjoyConnect:@"f140e798-78fb-4d82-bb05-365a24d59547" secretKey:@"D5oHobtuxnPIERTh9D3q"];
   //  [TapjoyConnect requestTapjoyConnect:@"69a22274-b6d6-4962-ba3b-d3772d9ec5f7" secretKey:@"JdO9lOmJITCwK6gx1f1i"];
    	//OR

      // A notification method must be set to retrieve the points.
       
  
    self.window = [[[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]] autorelease];
    
    if([[NSUserDefaults standardUserDefaults] boolForKey:@"loggedin"]){
        NSLog(@" Default is Yes");
    }
    else
    {
        NSLog(@" Default is No for first time");
        
        [[UIApplication sharedApplication] cancelAllLocalNotifications];
        
        [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"loggedin"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        
        UILocalNotification *notif = [[UILocalNotification alloc] init];
       // NSDate *date1 = [NSDate date];
    
     
        NSDate *mydate = [NSDate date];
        NSTimeInterval fifteeMint =  15 * 60;
        NSDate *dateAhead = [mydate dateByAddingTimeInterval:fifteeMint];
    
           
        notif.soundName = @"MessagePopupAlert.caf";
        notif.fireDate = dateAhead;
        notif.timeZone = [NSTimeZone defaultTimeZone];
        notif.alertBody = @"Have you checked the facts this week?";
        notif.alertAction = @"View";
        notif.repeatInterval = NSWeekCalendarUnit;
        
       // notif.repeatInterval = NSWeekOfMonthCalendarUnit;	
        [[UIApplication sharedApplication] scheduleLocalNotification:notif];
        [notif release];
 
    }
    
    
    
    
    
    //NSSetUncaughtExceptionHandler(&uncaughtExceptionHandler);
    [[UIApplication sharedApplication] setStatusBarHidden:YES];
    [[UIApplication sharedApplication] registerForRemoteNotificationTypes:(UIRemoteNotificationTypeBadge | UIRemoteNotificationTypeSound | UIRemoteNotificationTypeAlert)];
    
    //initialize push manager instance
    pushManager = [[PushNotificationManager alloc] initWithApplicationCode:PushWoosh_APP_Code appName:PushWoosh_APP_Name ];
    pushManager.delegate = self;
    [pushManager handlePushReceived:launchOptions];
    
    
    //--ChartBoost
    if([[NSUserDefaults standardUserDefaults] boolForKey:@"in_app_purchase"])
    {
        NSLog(@"saveeed");
        if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone)
        { 
            
            HomeScreen *hs=[[HomeScreen alloc]initWithNibName:@"HomeScreen" bundle:nil];
            
           // hs.cb = self.cb;
            
            nvct=[[UINavigationController alloc]initWithRootViewController:hs];
            
            self.window.rootViewController=nvct;
             [FlurryAds initialize:_window.rootViewController];
            [hs release];
            self.window.backgroundColor = [UIColor whiteColor];
            [self.window makeKeyAndVisible];
            return YES;
        }
        else
        {// Flurry HA91S3APQZJQAIVLMHJ4
            
            
            
            ipadHomeScreen *hsIpad=[[ipadHomeScreen alloc]initWithNibName:@"ipadHomeScreen" bundle:nil];
         //   hsIpad.cb=self.cb;
            nvct=[[UINavigationController alloc]initWithRootViewController:hsIpad];
            self.window.rootViewController=nvct;
             [FlurryAds initialize:_window.rootViewController];
            [hsIpad release];
            self.window.backgroundColor = [UIColor whiteColor];
            [self.window makeKeyAndVisible];
            return YES;
        }


    }
    else
    {
        
        NSLog(@"saveeed nott");
       

    
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone)
    { 

    HomeScreen *hs=[[HomeScreen alloc]initWithNibName:@"HomeScreen" bundle:nil];
        
        hs.cb = self.cb;
      
    nvct=[[UINavigationController alloc]initWithRootViewController:hs];
       
    self.window.rootViewController=nvct;
         [FlurryAds initialize:_window.rootViewController];
    [hs release];
        self.window.backgroundColor = [UIColor whiteColor];
        [self.window makeKeyAndVisible];
        return YES;
    }
    else
    {        
        ipadHomeScreen *hsIpad=[[ipadHomeScreen alloc]initWithNibName:@"ipadHomeScreen" bundle:nil];
        hsIpad.cb=self.cb;
        nvct=[[UINavigationController alloc]initWithRootViewController:hsIpad];
        self.window.rootViewController=nvct;
         [FlurryAds initialize:_window.rootViewController];
        [hsIpad release];
        self.window.backgroundColor = [UIColor whiteColor];
        [self.window makeKeyAndVisible];
        return YES;
    }
    
    }

   
    //[nvct setToolbarHidden:NO];
    
}

#pragma mark TapjoyConnect Observer methods

-(void) tjcConnectSuccess:(NSNotification*)notifyObj
{
	NSLog(@"Tapjoy Connect Succeeded");
	
	
}

-(void) tjcConnectFail:(NSNotification*)notifyObj
{
	NSLog(@"Tapjoy Connect Failed");
	
	
}



- (void)application:(UIApplication *)app didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)devToken {
    [pushManager handlePushRegistration:devToken];
    
    //you might want to send it to your backend if you use remote integration
    NSString *token = [pushManager getPushToken];
    NSLog(@"Push token: %@", token);
}

- (void)application:(UIApplication *)app didFailToRegisterForRemoteNotificationsWithError:(NSError *)err {
    NSLog(@"Error registering for push notifications. Error: %@", err);
}

- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo {
    [pushManager handlePushReceived:userInfo];
}
- (void)application:(UIApplication *)app didReceiveLocalNotification:(UILocalNotification *)notif {
    // Handle the notificaton when the app is running
  
   
        
        if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone)
        { 
            HomeScreen *pswd=[[HomeScreen alloc]initWithNibName:@"HomeScreen" bundle:nil];
           // [FlurryAnalytics logAllPageViews:nvct];
            [self.nvct pushViewController:pswd animated:YES];    
            [pswd release];
        }
        else
        {
            ipadHomeScreen *pwd=[[ipadHomeScreen alloc]initWithNibName:@"ipadHomeScreen" bundle:nil];
            [self.nvct pushViewController:pwd animated:YES]; 
            [pwd release];
        }
    
    
}
- (void)applicationWillResignActive:(UIApplication *)application
{
    /*
     Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
     Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
     */
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    /*
     Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
     If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
     */
      
}
- (void) onPushAccepted:(PushNotificationManager *)manager {
    //Handle Push Notification here
    
    NSLog(@"My Notification");
} 

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    /*
     Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
     */
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    /*
     Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
     */
    // Configure ChartBoost
    
    
    
     //[cb showInterstitial];
    if(![[NSUserDefaults standardUserDefaults] boolForKey:@"in_app_purchase"])
    {
        
    NSString *fAd=[NSString stringWithFormat:@"%@ Full Screen Ad",App_Full_Name_For_Email];
         [cb cacheInterstitial:fAd];
    [cb showInterstitial:fAd];
   
      [FlurryAds fetchAndDisplayAdForSpace:@"INTERSTITIAL_MAIN_VC" view:_window size:FULLSCREEN];
    
    [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(getDidLoadRevMob) userInfo:nil repeats:NO];
    }
   
       // Notify the beginning of a user session
    
   // [FlurryAnalytics logEvent:@"I-Pad Uni" timed:YES];
      
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    // Saves changes in the application's managed object context before the application terminates.
    [self saveContext];
}

- (void)saveContext
{
    NSError *error = nil;
    NSManagedObjectContext *managedObjectContext = self.managedObjectContext;
    if (managedObjectContext != nil)
    {
        if ([managedObjectContext hasChanges] && ![managedObjectContext save:&error])
        {
            /*
             Replace this implementation with code to handle the error appropriately.
             
             abort() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development. 
             */
            NSLog(@"Unresolved error %@, %@", error, [error userInfo]);
            abort();
        } 
    }
}

#pragma mark - Core Data stack

/**
 Returns the managed object context for the application.
 If the context doesn't already exist, it is created and bound to the persistent store coordinator for the application.
 */
- (NSManagedObjectContext *)managedObjectContext
{
    if (__managedObjectContext != nil)
    {
        return __managedObjectContext;
    }
    
    NSPersistentStoreCoordinator *coordinator = [self persistentStoreCoordinator];
    if (coordinator != nil)
    {
        __managedObjectContext = [[NSManagedObjectContext alloc] init];
        [__managedObjectContext setPersistentStoreCoordinator:coordinator];
    }
    return __managedObjectContext;
}

/**
 Returns the managed object model for the application.
 If the model doesn't already exist, it is created from the application's model.
 */
- (NSManagedObjectModel *)managedObjectModel
{
    if (__managedObjectModel != nil)
    {
        return __managedObjectModel;
    }
    NSURL *modelURL = [[NSBundle mainBundle] URLForResource:@"MJSAppTemplate" withExtension:@"momd"];
    __managedObjectModel = [[NSManagedObjectModel alloc] initWithContentsOfURL:modelURL];
    return __managedObjectModel;
}

/**
 Returns the persistent store coordinator for the application.
 If the coordinator doesn't already exist, it is created and the application's store added to it.
 */
- (NSPersistentStoreCoordinator *)persistentStoreCoordinator
{
    if (__persistentStoreCoordinator != nil)
    {
        return __persistentStoreCoordinator;
    }
    
    NSURL *storeURL = [[self applicationDocumentsDirectory] URLByAppendingPathComponent:@"MJSAppTemplate.sqlite"];
    
    NSError *error = nil;
    __persistentStoreCoordinator = [[NSPersistentStoreCoordinator alloc] initWithManagedObjectModel:[self managedObjectModel]];
    if (![__persistentStoreCoordinator addPersistentStoreWithType:NSSQLiteStoreType configuration:nil URL:storeURL options:nil error:&error])
    {
        /*
         Replace this implementation with code to handle the error appropriately.
         
         abort() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development. 
         
         Typical reasons for an error here include:
         * The persistent store is not accessible;
         * The schema for the persistent store is incompatible with current managed object model.
         Check the error message to determine what the actual problem was.
         
         
         If the persistent store is not accessible, there is typically something wrong with the file path. Often, a file URL is pointing into the application's resources directory instead of a writeable directory.
         
         If you encounter schema incompatibility errors during development, you can reduce their frequency by:
         * Simply deleting the existing store:
         [[NSFileManager defaultManager] removeItemAtURL:storeURL error:nil]
         
         * Performing automatic lightweight migration by passing the following dictionary as the options parameter: 
         [NSDictionary dictionaryWithObjectsAndKeys:[NSNumber numberWithBool:YES], NSMigratePersistentStoresAutomaticallyOption, [NSNumber numberWithBool:YES], NSInferMappingModelAutomaticallyOption, nil];
         
         Lightweight migration will only work for a limited set of schema changes; consult "Core Data Model Versioning and Data Migration Programming Guide" for details.
         
         */
        NSLog(@"Unresolved error %@, %@", error, [error userInfo]);
        abort();
    }    
    
    return __persistentStoreCoordinator;
}






#pragma mark - Application's Documents directory

/**
 Returns the URL to the application's Documents directory.
 */
- (NSURL *)applicationDocumentsDirectory
{
    return [[[NSFileManager defaultManager] URLsForDirectory:NSDocumentDirectory inDomains:NSUserDomainMask] lastObject];
}
-(void)getDidLoadRevMob
{
   // [RevMobAds showFullscreenAdWithAppID:RevMob_Full_Screen withDelegate:nil]; 
  //  [RevMobAds showFullscreenAdWithAppID:RevMob_Full_Screen withDelegate:self withSpecificOrientations:UIInterfaceOrientationPortrait,nil];
    
    RevMobAds *revmob = [RevMobAds revMobAds];
  //  RevMobFullscreen *fullscreen = [revmob fullscreenWithPlacementId:RevMob_Full_Screen];
    [revmob showFullscreen];

       
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone)
    {
//        // [RevMobAds showBannerAdWithDelegate:self withSpecificOrientations:UIInterfaceOrientationPortrait, nil];

//        RevMobAds *revmobs = [RevMobAds revMobAds];
//        RevMobBanner *bannerView = [revmobs bannerWithPlacementId:@"507911ea874e970c00000022"];
//        RevMobAds *revmobs = [RevMobAds revMobAds];
//       RevMobBanner *banner = [revmobs bannerWithPlacementId:@"507911ea874e970c00000022"];
//        banner.frame=CGRectMake(0.0f, 380.0f, 320.0f, 50.0f);
//       [banner showAd];
        
         [RevMobAds showBannerAdWithFrame:CGRectMake(0.0f, 380.0f, 320.0f, 50.0f) withDelegate:self];
       
        
       // [RevMobAds showBannerAdWithAppID:RevMob_Banner_ad withFrame:CGRectMake(0.0f, 380.0f, 320.0f, 50.0f) withDelegate:self withSpecificOrientations:UIInterfaceOrientationPortrait, nil];
    } else
            
        {
//             RevMobAds *revmobss = [RevMobAds revMobAds];
//            RevMobBanner *bannerViewIpad = [revmobss bannerWithPlacementId:@"507911ea874e970c00000022"];
//            bannerViewIpad.frame=CGRectMake(0.0f, 830.0f, 768.0f, 90.0f);
//            
//            [bannerViewIpad showAd];
            
             [RevMobAds showBannerAdWithFrame:CGRectMake(0.0f, 830.0f, 768.0f, 90.0f) withDelegate:self];
           // [RevMobAds showBannerAdWithDelegate:self withSpecificOrientations:UIInterfaceOrientationPortrait, nil];
         //   [RevMobAds showBannerAdWithAppID:RevMob_Banner_ad withFrame:CGRectMake(0.0f, 830.0f, 768.0f, 90.0f) withDelegate:self withSpecificOrientations:UIInterfaceOrientationPortrait, nil];
            
        }
    
     
    
    
}
//- (void) revmobUserClickedInTheAd {
- (void)revmobUserClickedInTheAd
{
    //[RevMobAds deactivateBannerAdWithAppID:RevMob_Banner_ad];    
//    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Yo" message:@"Clicked" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
//    [alert show];
//    [alert release];
    
}

@end
