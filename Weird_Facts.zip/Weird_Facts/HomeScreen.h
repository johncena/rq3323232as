//
//  HomeScreen.h
//  MJSAppTemplate
//
//  Created by Pairroxz on 15/01/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CSVParser.h"
#import <iAd/iAd.h>
#import "AppDelegate.h"
#import <StoreKit/StoreKit.h>
#import <CoreLocation/CoreLocation.h>
#import <SystemConfiguration/SystemConfiguration.h>
#import <MessageUI/MessageUI.h>
#import <RevMobAds/RevMobAdsDelegate.h>
#import "CustRev.h"
#import <AudioToolbox/AudioToolbox.h>
#import "Appirater.h"
#import "FBFeedPost.h"
#import "FBDialog.h"
#import <Twitter/Twitter.h>
#import "Mobclix.h"
#import "MobclixAds.h"
#import "MobclixAdView.h"
#import <QuartzCore/QuartzCore.h>
#import "Chartboost.h"
#import "MBProgressHUD.h"
#import "WToast.h"
#import "TapjoyConnect.h"
#import "Flurry.h"
#import "FlurryAdDelegate.h"
#import "FlurryAds.h"

#define kInAppPurchaseManagerProductsFetchedNotification @"kInAppPurchaseManagerProductsFetchedNotification" 
#define kInAppPurchaseManagerTransactionFailedNotification @"kInAppPurchaseManagerTransactionFailedNotification"
#define kInAppPurchaseManagerTransactionSucceededNotification @"kInAppPurchaseManagerTransactionSucceededNotification"
//#import "GADBannerView.h"
//#import "GADRequest.h"
//#import "GADBannerViewDelegate.h"
@interface MyRevMobAdsDelegate : NSObject<RevMobAdsDelegate>
@end
@interface HomeScreen : UIViewController<UIActionSheetDelegate,MFMailComposeViewControllerDelegate,MFMessageComposeViewControllerDelegate,CLLocationManagerDelegate,UIWebViewDelegate,ADBannerViewDelegate,FBFeedPostDelegate,UIAlertViewDelegate,RevMobAdsDelegate,MobclixAdViewDelegate,ChartboostDelegate,FBDialogDelegate,FBRequestDelegate,SKProductsRequestDelegate,SKPaymentTransactionObserver,FlurryAdDelegate>
{
   @private MobclixAdView *adMobclixView;
    UIToolbar *toolbar;
    NSInteger count;
    NSInteger index;
    NSInteger revIndex;
    NSInteger l;
    int elements;
    int m;
    BOOL bannerIsVisible;
    NSUserDefaults *defaults;
    SKProduct *proUpgradeProduct;
    SKProductsRequest *productsRequest;

}
//@property (nonatomic,assign) IBOutlet ADBannerView *adView;
-(void) proPackPurchased;
- (void)purchaseProUpgrade;
- (void)loadStore;
- (void)requestProUpgradeProductData;
@property (nonatomic,assign) BOOL bannerIsVisible;
@property (retain, nonatomic) IBOutlet ADBannerView *adView;
@property(nonatomic,retain) IBOutlet MobclixAdView *adMobclixView;
//@property (nonatomic, retain) ChartBoost *cb;
@property (retain,nonatomic) Chartboost *cb;
@property (retain, nonatomic) IBOutlet UIButton *nextItem;
//@property(retain,nonatomic)UIBarButtonItem *nextItem;
@property (retain, nonatomic) IBOutlet UIButton *PreviousItem;
//@property(retain,nonatomic)UIBarButtonItem *PreviousItem;
@property (retain, nonatomic) IBOutlet UIButton *moreItem;
//@property(retain,nonatomic) UIToolbar *toolbar;
@property (retain, nonatomic) IBOutlet UITextView *textView;
@property(retain,nonatomic)NSMutableArray *csvArray;
@property(retain,nonatomic)NSArray *tempArray;
@property(retain,nonatomic)NSMutableArray *colorArray;
- (IBAction)Prev_pressed:(id)sender;
- (IBAction)More_Pressed:(id)sender;
- (IBAction)Next_Pressed:(id)sender;

- (void)sendSMS:(NSString *)bodyOfMessage recipientList:(NSArray *)recipients;
- (CGRect)frameForToolbarAtOrientation:(UIInterfaceOrientation)orientation;
-(void)prevAction:(id)sender;
-(void)nextAction:(id)sender;
-(void)moreAction:(id)sender;
//-(CLLocation*)findCurrentLocation;
@property (retain, nonatomic) IBOutlet UIImageView *BGImgView;
//@property(nonatomic, retain) GADBannerView *adBanner;
//- (GADRequest *)createRequest;
-(void) askForFacebook;
-(void) postToFB;
-(void)getDidLoadRevMob;
-(void)geRevMobBanner;

-(void)HideRevMobBanner;
@end
